document.addEventListener('WeixinJSBridgeReady', function onBridgeReady() {
	//alert("lo:"+location.href);

/*
WeixinJSBridge.on('menu:share:timeline', function(argv) {		
WeixinJSBridge.invoke('sendAppMessage', {"img_url": "","img_width": "640","img_height": "640",
 "link": link, "desc": document.title, "title": document.title 	}, function(res) {})});
 WeixinJSBridge.on('menu:share:timeline', function(argv) { WeixinJSBridge.invoke('shareTimeline', {
 "img_url": "", "img_width": "640", "img_height": "640", "link": link, "desc": document.title, "title": document.title
 }, function(res) { }); });
 WeixinJSBridge.on('menu:share:weibo', function(argv) { WeixinJSBridge.invoke('shareWeibo', {
 "content": document.title, "url": link }, function(res) { }); });
 */
  }, false);